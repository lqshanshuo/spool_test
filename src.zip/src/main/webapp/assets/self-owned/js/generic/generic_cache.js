var CachePOJO = CachePOJO || {};
CachePOJO = {
    businessPOJO:null
};
